import React from 'react';
import { Newspaper } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t-2 border-stone-800 bg-[#f4efe6] text-stone-800 py-8 px-4 font-newspaper-serif mt-12">
      <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
        {/* Brand identity */}
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 bg-stone-900 text-amber-50 rounded-xs flex items-center justify-center">
            <Newspaper className="w-4 h-4" />
          </div>
          <span className="text-lg font-black font-newspaper-masthead text-stone-900 tracking-tight">
            THE DAILY YOU
          </span>
        </div>

        {/* Updated Tagline as requested */}
        <p className="text-xs sm:text-sm font-semibold text-stone-700 max-w-lg mb-4">
          “আপনিই আজকের সবচেয়ে বড় খবর!” — আপনার বাস্তবিক জীবনের নিউজ বের হলে কেমন হতো (অনলি ফর ফান)
        </p>

        {/* Bottom copyright & Designer link as requested */}
        <div className="text-xs text-stone-600 flex flex-wrap items-center justify-center gap-1.5 pt-2 border-t border-stone-300 w-full max-w-md">
          <span>&copy; 2026 The Daily You.</span>
          <span>•</span>
          <span>Designed by</span>
          <a
            href="https://www.facebook.com/nakibhaasan"
            target="_blank"
            rel="noopener noreferrer"
            className="text-stone-950 font-bold underline hover:text-amber-800 transition-colors"
          >
            Nakib Hasan
          </a>
        </div>
      </div>
    </footer>
  );
};
