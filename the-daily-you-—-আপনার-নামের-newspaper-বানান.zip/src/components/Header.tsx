import React from 'react';
import { Newspaper, Sparkles, RefreshCw } from 'lucide-react';
import { getBengaliNewspaperDate } from '../data/contentEngine';

interface HeaderProps {
  onNewClick?: () => void;
  showNewButton?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onNewClick, showNewButton }) => {
  const { bengali } = getBengaliNewspaperDate();

  return (
    <header className="border-b-2 border-stone-800 bg-[#fdfbf7] text-stone-900 shadow-xs">
      {/* Top micro-bar */}
      <div className="mx-auto max-w-5xl px-4 py-1.5 text-xs border-b border-stone-300 flex items-center justify-between font-newspaper-serif text-stone-600">
        <span className="flex items-center gap-1.5 font-medium text-[11px] sm:text-xs">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
          আজকের বিশেষ বাংলা প্রকাশনা
        </span>
        <span className="hidden sm:inline-block tracking-wide">{bengali}</span>
        <span className="font-semibold text-stone-800 text-[11px] sm:text-xs">মূল্য: বিনামূল্যে / অমূল্য হাসি</span>
      </div>

      {/* Main Masthead Banner - Centered on Mobile View */}
      <div className="mx-auto max-w-5xl px-4 py-3 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row items-center text-center sm:text-left gap-2 sm:gap-3 w-full sm:w-auto">
          <div className="w-10 h-10 sm:w-11 sm:h-11 bg-stone-900 text-amber-50 rounded-xs flex items-center justify-center shadow-xs shrink-0 mx-auto sm:mx-0">
            <Newspaper className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight font-newspaper-masthead text-stone-900 leading-none">
              THE DAILY YOU
            </h1>
            <p className="text-xs sm:text-sm font-newspaper-serif text-stone-700 font-medium mt-1">
              “আপনিই আজকের সবচেয়ে বড় খবর!”
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {showNewButton && onNewClick ? (
            <button
              onClick={onNewClick}
              className="flex items-center gap-1.5 bg-stone-900 hover:bg-stone-800 text-stone-50 px-3.5 py-1.5 rounded-md text-xs sm:text-sm font-newspaper-serif font-medium transition-colors shadow-xs cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>নতুন Newspaper</span>
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1.5 bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1 rounded-full text-xs font-newspaper-serif font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>১০ সেকেন্ডে তৈরি</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
