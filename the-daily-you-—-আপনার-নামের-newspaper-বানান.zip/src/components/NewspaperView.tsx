import React, { forwardRef, useEffect, useState, useRef } from 'react';
import { NewspaperContent } from '../types/newspaper';
import { Flame, Compass, Sun, ShieldAlert, Sparkles, ZoomIn, ZoomOut } from 'lucide-react';

interface NewspaperViewProps {
  content: NewspaperContent;
  websiteDomain?: string;
}

export const NewspaperView = forwardRef<HTMLDivElement, NewspaperViewProps>(
  ({ content, websiteDomain }, ref) => {
    const domainText = websiteDomain || (typeof window !== 'undefined' ? window.location.host : 'TheDailyYou.com');
    
    // Responsive scaling container for mobile viewports
    const wrapperRef = useRef<HTMLDivElement | null>(null);
    const [scale, setScale] = useState(1);
    const [zoomFit, setZoomFit] = useState(true);

    useEffect(() => {
      const updateScale = () => {
        if (!wrapperRef.current) return;
        const availableWidth = wrapperRef.current.clientWidth;
        if (availableWidth < 820 && zoomFit) {
          // Fit 800px into available screen width with padding
          const newScale = Math.max(0.38, Math.min(1, (availableWidth - 16) / 800));
          setScale(newScale);
        } else {
          setScale(1);
        }
      };

      updateScale();
      window.addEventListener('resize', updateScale);
      return () => window.removeEventListener('resize', updateScale);
    }, [zoomFit]);

    const newspaperHeight = 1120; // approximate height for height reservation when scaled

    return (
      <div className="w-full flex flex-col items-center py-2 sm:py-4 px-2" ref={wrapperRef}>
        {/* Mobile View Toggle: Zoom to fit vs 100% scrollable */}
        <div className="sm:hidden mb-2 flex items-center justify-between w-full max-w-[800px] px-1 text-xs font-newspaper-serif text-stone-600">
          <span className="flex items-center gap-1 font-semibold text-stone-800">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            পিসির মতো সম্পূর্ণ পত্রিকা
          </span>
          <button
            onClick={() => setZoomFit(!zoomFit)}
            className="flex items-center gap-1 bg-stone-200/90 active:bg-stone-300 text-stone-800 px-2.5 py-1 rounded-md text-[11px] font-bold"
          >
            {zoomFit ? <ZoomIn className="w-3 h-3" /> : <ZoomOut className="w-3 h-3" />}
            <span>{zoomFit ? 'বড় করে দেখুন' : 'স্ক্রিনে ফিট করুন'}</span>
          </button>
        </div>

        {/* Scrollable / Scaled wrapper */}
        <div
          className={`w-full flex justify-center ${zoomFit ? 'overflow-hidden' : 'overflow-x-auto pb-4'}`}
          style={{
            height: scale < 1 && zoomFit ? `${newspaperHeight * scale + 40}px` : 'auto',
          }}
        >
          <div
            style={{
              transform: zoomFit && scale < 1 ? `scale(${scale})` : 'none',
              transformOrigin: 'top center',
              width: '800px',
              minWidth: '800px',
            }}
          >
            {/* Master Broad-sheet Newspaper Canvas (Exactly 800px fixed width, never squishes or vertically stacks) */}
            <div
              ref={ref}
              id="newspaper-canvas"
              className="w-[800px] bg-[#fcfaf5] text-[#1c1917] p-8 rounded-xs border-4 border-[#1c1917] shadow-2xl relative select-text"
              style={{
                fontFamily: "'Noto Serif Bengali', Georgia, serif",
                backgroundColor: '#fcfaf5',
                boxSizing: 'border-box',
              }}
            >
              {/* TOP MASTHEAD SECTION */}
              <div className="border-b-2 border-[#1c1917] pb-3 mb-3">
                {/* Ear panels & micro-header */}
                <div className="grid grid-cols-4 gap-2 items-center pb-2 border-b border-stone-300">
                  {/* Left Ear: Weather & Mood */}
                  <div className="col-span-1 text-[11px] leading-tight border-r border-stone-300 pr-2">
                    <div className="flex items-center gap-1 font-bold text-stone-900 mb-0.5">
                      <Sun className="w-3.5 h-3.5 text-amber-700 inline" />
                      <span>মেজাজ ও আবহাওয়া</span>
                    </div>
                    <div className="text-stone-800 font-bold">{content.weatherReport.temp} • {content.weatherReport.condition}</div>
                    <div className="text-stone-600 text-[10px] mt-0.5 line-clamp-1">{content.weatherReport.forecast}</div>
                  </div>

                  {/* Center Micro Title */}
                  <div className="col-span-2 text-center">
                    <div className="text-[10px] uppercase tracking-widest font-black text-stone-600 font-newspaper-masthead">
                      THE PREMIER HUMOR & ENTERTAINMENT BROADSHEET
                    </div>
                    <div className="text-[12px] font-bold text-stone-900 font-newspaper-serif mt-0.5">
                      গণপ্রজাতন্ত্রী বন্ধুমহলের এক নম্বর মুখপত্র • শতভাগ নির্মল বিনোদন
                    </div>
                  </div>

                  {/* Right Ear: Edition & Pricing */}
                  <div className="col-span-1 text-[11px] leading-tight text-right border-l border-stone-300 pl-2">
                    <div className="font-bold text-stone-900">{content.volNo}</div>
                    <div className="text-stone-700">{content.editionNo}</div>
                    <div className="text-amber-900 font-bold text-[10px]">{content.price}</div>
                  </div>
                </div>

                {/* Giant Broadsheet Masthead Banner */}
                <div className="text-center pt-3 pb-1">
                  <h1
                    className="text-6xl font-black text-stone-950 uppercase tracking-normal leading-tight font-newspaper-masthead"
                    style={{ fontFamily: "'Cinzel', 'Noto Serif Bengali', Georgia, serif" }}
                  >
                    THE DAILY <span className="font-newspaper-serif font-black">{content.name}</span>
                  </h1>
                  <div className="flex items-center justify-center gap-3 mt-1.5">
                    <div className="h-[2px] w-28 bg-stone-900"></div>
                    <p className="text-base font-bold text-stone-800 tracking-wide font-newspaper-serif">
                      “আপনিই আজকের সবচেয়ে বড় খবর!”
                    </p>
                    <div className="h-[2px] w-28 bg-stone-900"></div>
                  </div>
                </div>
              </div>

              {/* Date & Issue Strip with Double Vintage Borders */}
              <div className="border-double-vintage py-1.5 px-2 mb-3.5 flex items-center justify-between text-xs font-semibold text-stone-800">
                <span>{content.bengaliDate}</span>
                <span className="text-stone-600 font-newspaper-masthead font-normal text-[11px]">
                  {content.englishDate}
                </span>
                <span className="text-red-700 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-600 inline-block"></span>
                  বিশেষ রঙিন প্রকাশনা
                </span>
              </div>

              {/* Breaking News Ribbon (Clear clearance, no overlapping) */}
              <div className="bg-red-700 text-white px-3 py-1.5 rounded-xs mb-4 flex items-center gap-2.5 shadow-xs">
                <span className="bg-white text-red-700 text-[11px] font-black px-2 py-0.5 rounded-xs tracking-wider uppercase shrink-0">
                  ব্রেকিং নিউজ
                </span>
                <span className="text-[13px] font-bold truncate tracking-wide">
                  {content.breakingTicker}
                </span>
              </div>

              {/* Main Broadsheet Grid: 2 Clean Columns (500px left, 230px right) */}
              <div className="grid grid-cols-12 gap-5 pb-4 border-b-2 border-stone-900">
                {/* Left 8 Columns: Main Hero Story, Classified Ad, Second Story */}
                <div className="col-span-8 flex flex-col justify-between">
                  {/* Main Headline Block */}
                  <div className="mb-3">
                    <div className="flex items-center gap-1.5 text-xs text-red-700 font-bold mb-1">
                      <Flame className="w-3.5 h-3.5 shrink-0" />
                      <span>প্রধান শিরোনাম • অনুসন্ধানী প্রতিবেদন</span>
                    </div>
                    <h2 className="text-3xl font-black text-stone-950 leading-[1.3] tracking-tight mb-2">
                      {content.mainHeadline}
                    </h2>
                    <p className="text-[14px] font-semibold text-stone-700 italic border-l-3 border-amber-700 pl-2.5 py-0.5">
                      {content.subHeadline}
                    </p>
                  </div>

                  {/* Byline */}
                  <div className="text-[11px] font-bold text-stone-600 pb-1.5 mb-3 border-b border-stone-300 flex items-center justify-between">
                    <span>— নিজস্ব বিশেষ প্রতিনিধি, ধানমন্ডি-গুলশান ব্যুরো</span>
                    <span>বিশেষ প্রতিবেদন</span>
                  </div>

                  {/* Article Text & Witty Classified Ad Box (Replacing the old image badge) */}
                  <div className="grid grid-cols-12 gap-4 mb-4">
                    {/* Left text column */}
                    <div className="col-span-7 text-[12.5px] leading-[1.65] text-stone-800 text-justify space-y-2">
                      <p className="font-normal">
                        <span className="font-bold text-stone-950 underline decoration-stone-400 mr-1">
                          নিজস্ব প্রতিবেদক:
                        </span>
                        {content.mainArticle[0]?.replace(/^নিজস্ব প্রতিবেদক সূত্রে জানা গেছে,\s*/, '')}
                      </p>
                      {content.mainArticle.slice(1).map((para, i) => (
                        <p key={i} className="font-normal">{para}</p>
                      ))}
                    </div>

                    {/* Right column: Humorous Classified Ad Box as requested */}
                    <div className="col-span-5 bg-[#fffef9] border-2 border-dashed border-stone-800 p-3 rounded-xs flex flex-col justify-between text-center relative shadow-xs">
                      {/* Ad Stamp */}
                      <div className="flex items-center justify-between border-b border-stone-300 pb-1 mb-2">
                        <span className="bg-stone-900 text-amber-50 text-[10px] font-black px-2 py-0.5 rounded-xs tracking-wider uppercase">
                          {content.adContent.tag}
                        </span>
                        <span className="text-[10px] font-bold text-stone-500 font-mono">AD-NO: #২৪</span>
                      </div>

                      <div className="my-auto py-1">
                        <h4 className="text-[13px] font-black text-stone-950 leading-snug mb-1.5">
                          {content.adContent.headline}
                        </h4>
                        <p className="text-[11px] leading-relaxed text-stone-700 font-serif">
                          {content.adContent.description}
                        </p>
                      </div>

                      <div className="mt-2 pt-1.5 border-t border-dashed border-stone-400 bg-amber-50/80 p-1.5 rounded-xs">
                        <span className="text-[10px] font-bold text-amber-950 block">
                          {content.adContent.contact}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Second Story (Personality) */}
                  <div className="pt-2.5 border-t-2 border-stone-800 bg-[#f9f6ed] p-3 rounded-xs border border-stone-300">
                    <div className="flex items-center justify-between mb-1">
                      <span className="bg-stone-900 text-amber-50 text-[10px] font-bold px-2 py-0.5 rounded-xs uppercase">
                        {content.secondNews.tag}
                      </span>
                      <span className="text-[10px] font-bold text-stone-500">বিশেষ প্রতিবেদন</span>
                    </div>
                    <h3 className="text-[16px] font-black text-stone-900 mb-1 leading-snug">
                      {content.secondNews.headline}
                    </h3>
                    <p className="text-[12px] text-stone-700 leading-[1.6] text-justify font-normal">
                      {content.secondNews.body}
                    </p>
                  </div>
                </div>

                {/* Right 4 Columns: Third Story, Fourth Story (Reaction), 24h Matrix, Editorial */}
                <div className="col-span-4 border-l-2 border-stone-900 pl-4 space-y-3.5">
                  {/* Third News (Plan) */}
                  <div className="border-b border-stone-300 pb-2.5">
                    <div className="bg-amber-800 text-white text-[10px] font-bold px-2 py-0.5 rounded-xs uppercase inline-block mb-1">
                      {content.thirdNews.tag}
                    </div>
                    <h3 className="text-[14px] font-black text-stone-900 leading-snug mb-1">
                      {content.thirdNews.headline}
                    </h3>
                    <p className="text-[11.5px] text-stone-700 leading-relaxed text-justify font-normal">
                      {content.thirdNews.body}
                    </p>
                  </div>

                  {/* Fourth News (Trouble Reaction - Q5) */}
                  <div className="border-b border-stone-300 pb-2.5 bg-stone-50/90 p-2 rounded-xs border border-stone-200">
                    <div className="bg-stone-800 text-amber-50 text-[10px] font-bold px-2 py-0.5 rounded-xs uppercase inline-block mb-1">
                      {content.fourthNews.tag}
                    </div>
                    <h3 className="text-[13px] font-black text-stone-900 leading-snug mb-1">
                      {content.fourthNews.headline}
                    </h3>
                    <p className="text-[11px] text-stone-700 leading-relaxed text-justify font-normal">
                      {content.fourthNews.body}
                    </p>
                  </div>

                  {/* Special Investigation Matrix (24 Hours Forecast) */}
                  <div className="bg-stone-100 p-2.5 rounded-xs border border-stone-300">
                    <h4 className="text-[12px] font-black text-stone-900 mb-1.5 border-b border-stone-400 pb-1 flex items-center gap-1">
                      <Compass className="w-3.5 h-3.5 text-stone-800" />
                      <span>{content.specialReport.title}</span>
                    </h4>
                    <div className="space-y-1.5 text-xs">
                      {content.specialReport.items.map((item, idx) => (
                        <div key={idx} className="border-b border-dashed border-stone-200 pb-1 last:border-0">
                          <div className="flex justify-between items-center text-[10.5px] font-semibold text-stone-800">
                            <span>{item.label}:</span>
                            <span className="font-bold text-amber-900">{item.status}</span>
                          </div>
                          <div className="w-full bg-stone-300 h-1 rounded-full mt-1 overflow-hidden">
                            <div
                              className="bg-stone-900 h-full rounded-full"
                              style={{ width: `${Math.min(100, (idx + 1) * 24)}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Editorial Wisdom Quote */}
                  <div className="border-l-3 border-stone-900 bg-[#fbf8f0] p-2 text-[11px] italic text-stone-800">
                    <p className="leading-snug">{content.editorialComment.quote}</p>
                    <p className="text-[9.5px] font-bold text-stone-600 mt-1 not-italic text-right">
                      {content.editorialComment.author}
                    </p>
                  </div>

                  {/* Horoscope */}
                  <div className="bg-amber-50/70 p-2 rounded-xs border border-amber-200 text-[11px]">
                    <div className="font-bold text-amber-900 text-[10.5px] mb-0.5">
                      দৈনিক রাশিফল ({content.horoscope.sign})
                    </div>
                    <p className="text-[10px] text-stone-700 leading-tight">
                      {content.horoscope.prediction}
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick News Tickers Ribbon */}
              <div className="pt-2 pb-1.5 border-b border-stone-400 flex items-center gap-x-3 text-xs text-stone-700 font-medium overflow-hidden">
                <span className="font-bold text-stone-900 shrink-0 flex items-center gap-1 text-[11px]">
                  <span className="w-1.5 h-1.5 rounded-full bg-stone-900"></span>
                  ঝটপট খবর:
                </span>
                {content.quickTickers.map((ticker, index) => (
                  <span key={index} className="inline-flex items-center gap-1.5 text-[10.5px] shrink-0">
                    {ticker}
                    {index < content.quickTickers.length - 1 && <span className="text-stone-400">•</span>}
                  </span>
                ))}
              </div>

              {/* Newspaper Footer with Viral Loop */}
              <div className="mt-2.5 pt-2 border-double-top-vintage flex items-center justify-between text-[10.5px] text-stone-600 font-newspaper-serif">
                <div className="flex items-center gap-1 font-bold text-stone-800">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                  <span>এই সংবাদপত্রটি সম্পূর্ণ কাল্পনিক এবং শুধুমাত্র বিনোদনের জন্য তৈরি।</span>
                </div>

                <div className="flex items-center gap-2 font-bold text-stone-900">
                  <span className="bg-stone-200 text-stone-800 px-1.5 py-0.5 rounded-xs font-mono text-[9.5px]">
                    THE DAILY YOU
                  </span>
                  <span>আপনার Newspaper বানান: <span className="text-amber-800 underline">{domainText}</span></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

NewspaperView.displayName = 'NewspaperView';
