import React from 'react';
import { Sparkles, ArrowDown } from 'lucide-react';
import { toBengaliNumerals } from '../data/contentEngine';

interface HeroProps {
  onStartClick: () => void;
  todayCount: number;
  totalCount: number;
}

export const Hero: React.FC<HeroProps> = ({ onStartClick, todayCount, totalCount }) => {
  return (
    <section className="relative overflow-hidden py-6 sm:py-12 border-b border-stone-300 bg-linear-to-b from-[#f9f7f2] to-[#f4efe6]">
      <div className="relative mx-auto max-w-4xl px-4 text-center">
        {/* Top badge */}
        <div className="inline-flex items-center gap-2 bg-stone-900 text-amber-50 px-3.5 py-1 rounded-full text-xs font-newspaper-serif font-bold tracking-wide mb-3 shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>লগইন ছাড়া ১০ সেকেন্ডে তৈরী করুন</span>
        </div>

        {/* Big headline */}
        <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-stone-900 font-newspaper-serif tracking-tight leading-tight mb-3">
          আজকের সবচেয়ে বড় খবর—<span className="text-amber-800 underline decoration-amber-600/40 decoration-4">আপনি নিজেই!</span>
        </h2>

        {/* Subheading */}
        <p className="text-sm sm:text-lg text-stone-700 font-newspaper-serif max-w-xl mx-auto mb-6 leading-relaxed">
          নিজের নামে একটা মজার Newspaper বানান। তারপর দেখুন আজ আপনাকে নিয়ে কী কী চাঞ্চল্যকর খবর বেরিয়েছে!
        </p>

        {/* Primary CTA button - Mobile 1-line guaranteed with single emoji */}
        <div className="flex justify-center mb-6">
          <button
            onClick={onStartClick}
            className="w-auto inline-flex items-center justify-center gap-2 bg-stone-950 hover:bg-stone-800 active:scale-[0.98] text-amber-50 px-5 sm:px-8 py-3 sm:py-3.5 rounded-xl text-base sm:text-lg font-newspaper-serif font-bold transition-all shadow-md hover:shadow-lg border border-stone-800 cursor-pointer whitespace-nowrap"
          >
            <span>📰 আমার Newspaper বানান</span>
            <ArrowDown className="w-4 h-4 opacity-80" />
          </button>
        </div>

        {/* Counters: Today Count & Total Count (2 clean cards) */}
        <div className="grid grid-cols-2 gap-3 max-w-md mx-auto text-stone-800 font-newspaper-serif text-xs sm:text-sm">
          {/* Card 1: Today */}
          <div className="bg-[#fcfaf5] p-3 rounded-xl border border-stone-300 shadow-xs flex flex-col items-center justify-center">
            <span className="text-[11px] sm:text-xs text-stone-600 font-semibold mb-0.5">
              আজকে নিউজ তৈরি হয়েছে
            </span>
            <span className="text-xl sm:text-2xl font-black text-amber-900 font-newspaper-serif">
              {toBengaliNumerals(todayCount)} টি
            </span>
          </div>

          {/* Card 2: Total */}
          <div className="bg-[#fcfaf5] p-3 rounded-xl border border-stone-300 shadow-xs flex flex-col items-center justify-center">
            <span className="text-[11px] sm:text-xs text-stone-600 font-semibold mb-0.5">
              সর্বমোট নিউজ তৈরি হয়েছে
            </span>
            <span className="text-xl sm:text-2xl font-black text-stone-950 font-newspaper-serif">
              {toBengaliNumerals(totalCount)} টি
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
