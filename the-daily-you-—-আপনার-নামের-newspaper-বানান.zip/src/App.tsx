/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { GeneratorForm } from './components/GeneratorForm';
import { PrintingAnimation } from './components/PrintingAnimation';
import { NewspaperView } from './components/NewspaperView';
import { ShareActions } from './components/ShareActions';
import { Footer } from './components/Footer';
import { UserSelections, NewspaperContent } from './types/newspaper';
import { generateNewspaper } from './data/contentEngine';

export default function App() {
  const [view, setView] = useState<'home' | 'printing' | 'newspaper'>('home');
  const [selections, setSelections] = useState<UserSelections | null>(null);
  const [content, setContent] = useState<NewspaperContent | null>(null);
  const [cycleIndex, setCycleIndex] = useState<number>(0);
  const newspaperRef = useRef<HTMLDivElement | null>(null);

  // Live persistent counters with requested defaults: 48 (today) and 174 (total)
  const [todayCount, setTodayCount] = useState<number>(() => {
    try {
      const savedDate = localStorage.getItem('daily_you_date');
      const todayStr = new Date().toDateString();
      if (savedDate !== todayStr) {
        localStorage.setItem('daily_you_date', todayStr);
        localStorage.setItem('daily_you_today_count', '48');
        return 48;
      }
      const saved = localStorage.getItem('daily_you_today_count');
      return saved ? parseInt(saved, 10) : 48;
    } catch {
      return 48;
    }
  });

  const [totalCount, setTotalCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('daily_you_total_count');
      return saved ? parseInt(saved, 10) : 174;
    } catch {
      return 174;
    }
  });

  const incrementCounters = () => {
    setTodayCount((prev) => {
      const next = prev + 1;
      try {
        localStorage.setItem('daily_you_today_count', String(next));
      } catch {
        // ignore
      }
      return next;
    });

    setTotalCount((prev) => {
      const next = prev + 1;
      try {
        localStorage.setItem('daily_you_total_count', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Scroll smoothly to generator
  const scrollToGenerator = () => {
    setView('home');
    setTimeout(() => {
      const el = document.getElementById('generator-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  // User submits form to create newspaper
  const handleFormSubmit = (submitted: UserSelections) => {
    setSelections(submitted);
    incrementCounters();

    // Generate unique news for this cycle
    const nextCycle = cycleIndex;
    const newContent = generateNewspaper(submitted, nextCycle);
    setContent(newContent);
    setCycleIndex((prev) => (prev + 1) % 5);

    setView('printing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // When printing animation finishes (~1.5s)
  const handlePrintingFinish = () => {
    setView('newspaper');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    try {
      confetti({
        particleCount: 60,
        spread: 65,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }
  };

  // Regenerate with same inputs but guaranteed NEW story from the 5-rotation pool
  const handleRegenerate = () => {
    if (!selections) return;
    incrementCounters();
    const nextCycle = cycleIndex;
    const fresh = generateNewspaper(selections, nextCycle);
    setContent(fresh);
    setCycleIndex((prev) => (prev + 1) % 5);
    window.scrollTo({ top: 120, behavior: 'smooth' });
    try {
      confetti({
        particleCount: 35,
        spread: 45,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }
  };

  // Reset to make a friend's newspaper
  const handleMakeNew = () => {
    setSelections(null);
    setContent(null);
    setView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      const el = document.getElementById('generator-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f6f3ed] text-[#1a1a1a]">
      {/* Top Header */}
      <Header
        onNewClick={handleMakeNew}
        showNewButton={view === 'newspaper'}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {view === 'home' && (
          <>
            <Hero
              onStartClick={scrollToGenerator}
              todayCount={todayCount}
              totalCount={totalCount}
            />
            <GeneratorForm
              onSubmit={handleFormSubmit}
              initialValues={selections || undefined}
            />
          </>
        )}

        {view === 'printing' && selections && (
          <PrintingAnimation
            name={selections.name}
            onFinish={handlePrintingFinish}
          />
        )}

        {view === 'newspaper' && content && (
          <div className="py-2 sm:py-6 animate-fadeIn">
            {/* Top Bar with status & action hint */}
            <div className="max-w-4xl mx-auto px-4 mb-2 flex items-center justify-between text-xs sm:text-sm font-newspaper-serif text-stone-600">
              <span className="flex items-center gap-1.5 font-bold text-stone-900">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse"></span>
                আপনার নামের সংবাদপত্র প্রস্তুত!
              </span>
              <button
                onClick={handleMakeNew}
                className="text-amber-800 hover:underline font-bold cursor-pointer"
              >
                &larr; নতুন করে শুরু করুন
              </button>
            </div>

            {/* The Actual Broadsheet Newspaper Container */}
            <NewspaperView
              ref={newspaperRef}
              content={content}
            />

            {/* Action Buttons: Download PNG, Web Share, Regenerate, New Friend */}
            <ShareActions
              newspaperRef={newspaperRef}
              content={content}
              onRegenerate={handleRegenerate}
              onMakeNew={handleMakeNew}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
