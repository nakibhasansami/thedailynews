import React, { useState } from 'react';
import { HabitType, PersonalityType, PlanType, TroubleReactionType, UserSelections } from '../types/newspaper';
import { HABIT_OPTIONS, PERSONALITY_OPTIONS, PLAN_OPTIONS, REACTION_OPTIONS, SAMPLE_NAMES } from '../data/options';
import { Check, Sparkles, User, AlertCircle, ArrowRight } from 'lucide-react';

interface GeneratorFormProps {
  onSubmit: (selections: UserSelections) => void;
  initialValues?: Partial<UserSelections>;
}

export const GeneratorForm: React.FC<GeneratorFormProps> = ({ onSubmit, initialValues }) => {
  const [name, setName] = useState(initialValues?.name || '');
  const [habit, setHabit] = useState<HabitType>(initialValues?.habit || 'procrastination');
  const [personality, setPersonality] = useState<PersonalityType>(initialValues?.personality || 'funny');
  const [plan, setPlan] = useState<PlanType>(initialValues?.plan || 'sleep_more');
  const [reaction, setReaction] = useState<TroubleReactionType>(initialValues?.reaction || 'run_away');
  const [nameError, setNameError] = useState('');

  const sanitizeName = (raw: string): string => {
    // Keep Bengali letters, English letters, spaces, hyphens, and remove HTML/script tags
    return raw
      .replace(/<[^>]*>?/gm, '')
      .replace(/["'`;<>]/g, '')
      .slice(0, 30);
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = sanitizeName(e.target.value);
    setName(val);
    if (val.trim()) {
      setNameError('');
    }
  };

  const handleSampleNameClick = (sample: string) => {
    setName(sample);
    setNameError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = name.trim();
    if (!clean) {
      setNameError('দয়া করে আপনার বা আপনার বন্ধুর নামটি লিখুন');
      document.getElementById('name-input')?.focus();
      return;
    }

    if (clean.length < 2) {
      setNameError('নামটি অন্তত ২ অক্ষরের হতে হবে');
      return;
    }

    onSubmit({
      name: clean,
      habit,
      personality,
      plan,
      reaction,
    });
  };

  return (
    <section id="generator-section" className="py-6 sm:py-10 px-3 sm:px-4 max-w-4xl mx-auto">
      <div className="newspaper-paper border-2 border-stone-800 rounded-2xl p-4 sm:p-8 shadow-lg">
        {/* Form Header */}
        <div className="text-center pb-5 border-b-2 border-stone-800 mb-6">
          <div className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-900 border border-amber-300 px-3 py-0.5 rounded-full text-xs font-newspaper-serif font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>মাত্র ৫টি ক্লিকে আপনার পত্রিকা</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black font-newspaper-serif text-stone-900 tracking-tight">
            নিউজপেপার তৈরির তথ্য দিন
          </h3>
          <p className="text-xs sm:text-sm font-newspaper-serif text-stone-600 mt-0.5">
            লগইন ছাড়া ১০ সেকেন্ডে আপনার ও বন্ধুদের জন্য পত্রিকা বানিয়ে নিন
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Input 1: Name */}
          <div className="bg-[#fcfaf5] p-3.5 sm:p-5 rounded-xl border border-stone-300">
            <label
              htmlFor="name-input"
              className="flex items-center justify-between text-base font-bold font-newspaper-serif text-stone-900 mb-2"
            >
              <span className="flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-stone-900 text-stone-100 text-xs flex items-center justify-center font-bold">১</span>
                আপনার নাম কী? <span className="text-red-600">*</span>
              </span>
              <span className="text-xs text-stone-500 font-normal">বাংলা বা ইংরেজি</span>
            </label>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                <User className="w-4 h-4" />
              </div>
              <input
                id="name-input"
                type="text"
                value={name}
                onChange={handleNameChange}
                placeholder="বাংলাতে নাম লিখুন"
                maxLength={30}
                className={`w-full pl-10 pr-3 py-3 rounded-xl text-base font-newspaper-serif text-stone-900 bg-white border-2 ${
                  nameError ? 'border-red-500 ring-2 ring-red-100' : 'border-stone-400 focus:border-stone-900'
                } focus:outline-hidden transition-all placeholder:text-stone-400`}
              />
            </div>

            {nameError && (
              <p className="mt-2 text-xs sm:text-sm font-newspaper-serif text-red-600 flex items-center gap-1.5 font-medium animate-fadeIn">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {nameError}
              </p>
            )}

            {/* Quick Name Chips as requested */}
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-newspaper-serif text-stone-600 font-medium">দ্রুত বেছে নিন:</span>
              {SAMPLE_NAMES.map((sample) => (
                <button
                  key={sample}
                  type="button"
                  onClick={() => handleSampleNameClick(sample)}
                  className="text-xs bg-stone-200/80 hover:bg-stone-300 active:bg-amber-200 text-stone-900 px-2.5 py-1 rounded-md font-newspaper-serif font-medium transition-colors cursor-pointer"
                >
                  {sample}
                </button>
              ))}
            </div>
          </div>

          {/* Input 2: Habit (Updated label: আপনি মানুষ আসলে কেমন?) */}
          <div>
            <div className="flex items-center gap-2 text-base font-bold font-newspaper-serif text-stone-900 mb-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-stone-100 text-xs flex items-center justify-center font-bold">২</span>
              <span>আপনি মানুষ আসলে কেমন?</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {HABIT_OPTIONS.map((item) => {
                const isSelected = habit === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setHabit(item.id)}
                    className={`p-3.5 rounded-xl text-left border-2 transition-all flex items-start justify-between cursor-pointer ${
                      isSelected
                        ? 'border-stone-950 bg-stone-900 text-amber-50 shadow-md ring-2 ring-stone-950/20'
                        : 'border-stone-300 bg-[#fdfbf7] hover:border-stone-500 text-stone-800'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl shrink-0">{item.emoji}</span>
                      <div>
                        <div className={`font-bold font-newspaper-serif text-sm sm:text-base ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                          {item.label}
                        </div>
                        <div className={`text-xs font-newspaper-serif mt-0.5 ${isSelected ? 'text-stone-300' : 'text-stone-600'}`}>
                          {item.tagline}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-1 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-400 text-stone-950'
                          : 'border-stone-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Input 3: Personality */}
          <div>
            <div className="flex items-center gap-2 text-base font-bold font-newspaper-serif text-stone-900 mb-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-stone-100 text-xs flex items-center justify-center font-bold">৩</span>
              <span>বন্ধুরা আপনাকে কীভাবে চেনে?</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {PERSONALITY_OPTIONS.map((item) => {
                const isSelected = personality === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPersonality(item.id)}
                    className={`p-3.5 rounded-xl text-left border-2 transition-all flex items-start justify-between cursor-pointer ${
                      isSelected
                        ? 'border-stone-950 bg-stone-900 text-amber-50 shadow-md ring-2 ring-stone-950/20'
                        : 'border-stone-300 bg-[#fdfbf7] hover:border-stone-500 text-stone-800'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl shrink-0">{item.emoji}</span>
                      <div>
                        <div className={`font-bold font-newspaper-serif text-sm sm:text-base ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                          {item.label}
                        </div>
                        <div className={`text-xs font-newspaper-serif mt-0.5 ${isSelected ? 'text-stone-300' : 'text-stone-600'}`}>
                          {item.tagline}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-1 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-400 text-stone-950'
                          : 'border-stone-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Input 4: Plan */}
          <div>
            <div className="flex items-center gap-2 text-base font-bold font-newspaper-serif text-stone-900 mb-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-stone-100 text-xs flex items-center justify-center font-bold">৪</span>
              <span>আজ আপনার প্রধান পরিকল্পনা কী?</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {PLAN_OPTIONS.map((item) => {
                const isSelected = plan === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPlan(item.id)}
                    className={`p-3.5 rounded-xl text-left border-2 transition-all flex items-start justify-between cursor-pointer ${
                      isSelected
                        ? 'border-stone-950 bg-stone-900 text-amber-50 shadow-md ring-2 ring-stone-950/20'
                        : 'border-stone-300 bg-[#fdfbf7] hover:border-stone-500 text-stone-800'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl shrink-0">{item.emoji}</span>
                      <div>
                        <div className={`font-bold font-newspaper-serif text-sm sm:text-base ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                          {item.label}
                        </div>
                        <div className={`text-xs font-newspaper-serif mt-0.5 ${isSelected ? 'text-stone-300' : 'text-stone-600'}`}>
                          {item.tagline}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-1 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-400 text-stone-950'
                          : 'border-stone-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Input 5: Reaction to trouble (New 5th Question) */}
          <div>
            <div className="flex items-center gap-2 text-base font-bold font-newspaper-serif text-stone-900 mb-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-stone-100 text-xs flex items-center justify-center font-bold">৫</span>
              <span>কোনো বিপদে পড়লে আপনার প্রথম প্রতিক্রিয়া কী?</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {REACTION_OPTIONS.map((item) => {
                const isSelected = reaction === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setReaction(item.id)}
                    className={`p-3.5 rounded-xl text-left border-2 transition-all flex items-start justify-between cursor-pointer ${
                      isSelected
                        ? 'border-stone-950 bg-stone-900 text-amber-50 shadow-md ring-2 ring-stone-950/20'
                        : 'border-stone-300 bg-[#fdfbf7] hover:border-stone-500 text-stone-800'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl shrink-0">{item.emoji}</span>
                      <div>
                        <div className={`font-bold font-newspaper-serif text-sm sm:text-base ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                          {item.label}
                        </div>
                        <div className={`text-xs font-newspaper-serif mt-0.5 ${isSelected ? 'text-stone-300' : 'text-stone-600'}`}>
                          {item.tagline}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-1 ${
                        isSelected
                          ? 'border-amber-400 bg-amber-400 text-stone-950'
                          : 'border-stone-400'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submit CTA - 1 Line on Mobile Guaranteed: নিউজ তৈরী করুন */}
          <div className="pt-3 border-t-2 border-stone-800">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-stone-950 hover:bg-stone-800 active:scale-[0.99] text-amber-50 py-3.5 sm:py-4 px-4 rounded-xl text-base sm:text-lg font-bold font-newspaper-serif transition-all shadow-md hover:shadow-xl cursor-pointer border border-stone-800 whitespace-nowrap"
            >
              <span>🗞️ নিউজ তৈরী করুন</span>
              <ArrowRight className="w-4 h-4 text-amber-400 shrink-0" />
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};
