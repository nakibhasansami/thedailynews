import { HabitType, PersonalityType, PlanType, TroubleReactionType } from '../types/newspaper';

export interface OptionItem<T> {
  id: T;
  label: string;
  tagline: string;
  emoji: string;
}

export const HABIT_OPTIONS: OptionItem<HabitType>[] = [
  {
    id: 'procrastination',
    label: 'কাজ পরে করব',
    tagline: 'আজকের কাজ আগামীকাল, কালকের কাজ পরশু!',
    emoji: '😴',
  },
  {
    id: 'phone_addict',
    label: 'ফোন ছাড়া থাকতে পারি না',
    tagline: 'চার্জ ১০% হলেও স্ক্রোলিং থামবে না',
    emoji: '📱',
  },
  {
    id: 'food_lover',
    label: 'খাবারই প্রথম ভালোবাসা',
    tagline: 'মন খারাপ? সমাধান একটাই: গরম বিরিয়ানি!',
    emoji: '🍔',
  },
  {
    id: 'always_late',
    label: 'সব জায়গায় দেরি করি',
    tagline: '“৫ মিনিটে আসছি” মানে অন্তত পৌনে এক ঘণ্টা',
    emoji: '⏰',
  },
];

export const PERSONALITY_OPTIONS: OptionItem<PersonalityType>[] = [
  {
    id: 'funny',
    label: 'হাসির মানুষ',
    tagline: 'যেখানে যান, হাসির বন্যা বইয়ে দেন',
    emoji: '😂',
  },
  {
    id: 'ghost',
    label: 'হঠাৎ গায়েব',
    tagline: 'সিন করে রিপ্লাই না দিয়ে হাওয়ায় মিলিয়ে যাওয়া',
    emoji: '👻',
  },
  {
    id: 'always_cool',
    label: 'সবসময় কুল',
    tagline: 'ঝড়-তুফান আসলেও মুখে একটাই কথা: “চিল ব্রো!”',
    emoji: '😎',
  },
  {
    id: 'helpful',
    label: 'সবার বিপদে পাশে',
    tagline: 'রাত ২টায় ফোন দিলেও সবসময় হাজির',
    emoji: '🤝',
  },
];

export const PLAN_OPTIONS: OptionItem<PlanType>[] = [
  {
    id: 'sleep_more',
    label: 'আরেকটু ঘুমাব',
    tagline: 'বিছানার সঙ্গে আজ ঐতিহাসিক মৈত্রী চুক্তি',
    emoji: '🛌',
  },
  {
    id: 'watch_movies',
    label: 'সিনেমা বা ভিডিও দেখব',
    tagline: '“শুধু আর একটা পর্ব” দেখে পুরো সিজন শেষ',
    emoji: '🎬',
  },
  {
    id: 'start_new',
    label: 'নতুন কিছু শুরু করব',
    tagline: 'জীবন পাল্টানোর বিরাট সংকল্প (যদিও কাল থেকে)',
    emoji: '🚀',
  },
  {
    id: 'adda_friends',
    label: 'বন্ধুদের সঙ্গে আড্ডা দেব',
    tagline: 'চায়ের টঙে বিশ্বরাজনীতি ও ভবিষ্যৎ নিয়ে তুমুল তর্ক',
    emoji: '🍕',
  },
];

export const REACTION_OPTIONS: OptionItem<TroubleReactionType>[] = [
  {
    id: 'run_away',
    label: 'সোজা উল্টো দিকে দৌড়',
    tagline: 'ঝামেলা দেখলেই নিঃশব্দে নিরাপদ দূরত্ব বজায় রাখা',
    emoji: '🏃‍♂️',
  },
  {
    id: 'drink_tea',
    label: 'এক কাপ চা খেয়ে চিন্তা করি',
    tagline: 'চায়ে চুমুক দিয়ে বিশ্ব উদ্ধারের প্ল্যান বানানো',
    emoji: '☕',
  },
  {
    id: 'pretend_unknown',
    label: 'ভাব ধরি আমি কিছুই জানি না',
    tagline: 'সবচেয়ে নিষ্পাপ ও অসহায় চাহনি দিয়ে তাকিয়ে থাকা',
    emoji: '🤷‍♂️',
  },
  {
    id: 'google_solution',
    label: 'গুগল বা ইউটিউবে সমাধান খুঁজি',
    tagline: '“৫ মিনিটে বিপদ থেকে বাঁচার উপায়” লিখে সার্চ',
    emoji: '📲',
  },
];

export const SAMPLE_NAMES = ['লিজান', 'আজিজ', 'রেদোয়ান', 'সাঈদ', 'ইমরান', 'ফাহিম', 'নাঈম'];
