import React, { useEffect, useState } from 'react';
import { Newspaper, Printer } from 'lucide-react';

interface PrintingAnimationProps {
  name: string;
  onFinish: () => void;
}

export const PrintingAnimation: React.FC<PrintingAnimationProps> = ({ name, onFinish }) => {
  const [stepText, setStepText] = useState('প্রেস মেশিনে কাগজ লোড হচ্ছে...');
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const t1 = setTimeout(() => {
      setStepText('কালি লাগানো হচ্ছে ও রোটারি ড্রাম ঘুরছে...');
      setProgress(45);
    }, 400);

    const t2 = setTimeout(() => {
      setStepText(`ব্রেকিং শিরোনাম ছাপানো হচ্ছে: "${name}-এর চাঞ্চল্যকর খবর"...`);
      setProgress(75);
    }, 850);

    const t3 = setTimeout(() => {
      setStepText('পত্রিকা ভাঁজ করা হচ্ছে ও প্রথম পাতা প্রস্তুত!');
      setProgress(100);
    }, 1250);

    const t4 = setTimeout(() => {
      onFinish();
    }, 1500);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [name, onFinish]);

  return (
    <div className="min-h-[500px] flex items-center justify-center px-4 py-16">
      <div className="newspaper-paper border-2 border-stone-800 rounded-2xl p-8 sm:p-12 max-w-md w-full text-center shadow-xl relative overflow-hidden">
        {/* Animated stamp background */}
        <div className="w-20 h-20 mx-auto mb-6 bg-stone-900 text-amber-50 rounded-2xl flex items-center justify-center relative shadow-inner">
          <Printer className="w-10 h-10 animate-bounce text-amber-400" />
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center text-[10px] text-white font-bold animate-ping">
            •
          </div>
        </div>

        <h3 className="text-2xl sm:text-3xl font-black font-newspaper-serif text-stone-900 mb-2">
          আজকের খবর ছাপা হচ্ছে…
        </h3>

        <p className="text-sm font-newspaper-serif text-stone-600 mb-6 h-6 transition-all duration-300">
          {stepText}
        </p>

        {/* Realistic Ink Press Progress Bar */}
        <div className="w-full bg-stone-200 h-3 rounded-full overflow-hidden border border-stone-300 p-0.5">
          <div
            className="bg-stone-900 h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-stone-500 font-newspaper-serif">
          <Newspaper className="w-3.5 h-3.5" />
          <span>দ্য ডেইলি ইউ প্রেস শাখা • ঢাকা</span>
        </div>
      </div>
    </div>
  );
};
