export type HabitType = 'procrastination' | 'phone_addict' | 'food_lover' | 'always_late';
export type PersonalityType = 'funny' | 'ghost' | 'always_cool' | 'helpful';
export type PlanType = 'sleep_more' | 'watch_movies' | 'start_new' | 'adda_friends';
export type TroubleReactionType = 'run_away' | 'drink_tea' | 'pretend_unknown' | 'google_solution';

export interface UserSelections {
  name: string;
  habit: HabitType;
  personality: PersonalityType;
  plan: PlanType;
  reaction: TroubleReactionType;
}

export interface NewspaperContent {
  id: string;
  name: string;
  englishName: string;
  bengaliDate: string;
  englishDate: string;
  editionNo: string;
  price: string;
  volNo: string;
  weatherReport: {
    temp: string;
    condition: string;
    forecast: string;
  };
  breakingTicker: string;
  mainHeadline: string;
  subHeadline: string;
  mainArticle: string[];
  // Funny Classified Ad
  adContent: {
    tag: string;
    headline: string;
    description: string;
    contact: string;
  };
  secondNews: {
    tag: string;
    headline: string;
    body: string;
  };
  thirdNews: {
    tag: string;
    headline: string;
    body: string;
  };
  fourthNews: {
    tag: string;
    headline: string;
    body: string;
  };
  quickTickers: string[];
  specialReport: {
    title: string;
    items: {
      label: string;
      status: string;
      gauge: string;
    }[];
  };
  editorialComment: {
    quote: string;
    author: string;
  };
  horoscope: {
    sign: string;
    prediction: string;
  };
  generatedAt: number;
}
