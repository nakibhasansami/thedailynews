import React, { useState } from 'react';
import { toPng } from 'html-to-image';
import confetti from 'canvas-confetti';
import { Download, Share2, RefreshCw, UserPlus, Check, MessageCircle, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { NewspaperContent } from '../types/newspaper';

interface ShareActionsProps {
  newspaperRef: React.RefObject<HTMLDivElement | null>;
  content: NewspaperContent;
  onRegenerate: () => void;
  onMakeNew: () => void;
}

export const ShareActions: React.FC<ShareActionsProps> = ({
  newspaperRef,
  content,
  onRegenerate,
  onMakeNew,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [previewBlobUrl, setPreviewBlobUrl] = useState<string | null>(null);

  // High-reliability download for Mobile & Desktop
  const handleDownloadPng = async () => {
    if (!newspaperRef.current) {
      setExportError('পত্রিকা খুঁজে পাওয়া যায়নি। দয়া করে আবার চেষ্টা করুন।');
      return;
    }

    try {
      setIsExporting(true);
      setExportError(null);

      // Ensure all custom fonts are ready
      if (document.fonts) {
        await document.fonts.ready;
      }

      await new Promise((resolve) => setTimeout(resolve, 150));

      const node = newspaperRef.current;
      
      // Capture at unscaled 800px broadsheet resolution
      const dataUrl = await toPng(node, {
        quality: 0.98,
        pixelRatio: 2, // 2x crisp HD resolution
        backgroundColor: '#fcfaf5',
        cacheBust: true,
        style: {
          transform: 'none',
          transformOrigin: 'top left',
          margin: '0 auto',
        },
      });

      // Convert dataUrl to Blob for reliable mobile browser downloading
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      setPreviewBlobUrl(blobUrl);

      const cleanFileName = `The_Daily_${content.name.replace(/[^a-zA-Z0-9\u0980-\u09FF]/g, '_') || 'You'}.png`;

      // Try native Web Share API with image file if on mobile (saves directly to Photos / Gallery)
      const file = new File([blob], cleanFileName, { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            title: `The Daily ${content.name}`,
            text: `📰 দ্য ডেইলি ${content.name}: "${content.mainHeadline}"`,
            files: [file],
          });
          setDownloadSuccess(true);
          setTimeout(() => setDownloadSuccess(false), 5000);
          confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
          return;
        } catch (err: unknown) {
          if (err instanceof Error && err.name === 'AbortError') {
            // User cancelled share dialog, continue with anchor fallback
          }
        }
      }

      // Universal anchor blob download fallback
      const link = document.createElement('a');
      link.download = cleanFileName;
      link.href = blobUrl;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 5000);

      // Confetti
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
        });
      } catch {
        // ignore
      }
    } catch (err) {
      console.error('Export error:', err);
      setExportError('ডাউনলোড করতে সমস্যা হলে নিচের "ছবি সরাসরি খুলুন" বাটনে ক্লিক করে সেভ করুন।');
    } finally {
      setIsExporting(false);
    }
  };

  const handleShare = async () => {
    const currentUrl = window.location.href;
    const shareText = `📰 দ্য ডেইলি ${content.name}: "${content.mainHeadline}"\n\nআপনিও আপনার নামের মজার সংবাদপত্র বানিয়ে দেখুন:`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `The Daily ${content.name}`,
          text: shareText,
          url: currentUrl,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(`${shareText}\n${currentUrl}`);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    } catch {
      // fallback
    }
  };

  const handleWhatsAppShare = () => {
    const currentUrl = window.location.href;
    const shareText = `📰 দ্য ডেইলি ${content.name}: "${content.mainHeadline}"\n\nআপনার নামের সংবাদপত্র বানান:\n${currentUrl}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-4">
      {/* Export Error Alert with Direct View Link */}
      {exportError && (
        <div className="mb-4 p-3 bg-red-100 border border-red-300 rounded-lg text-red-800 text-xs sm:text-sm font-newspaper-serif text-center flex flex-col items-center gap-2">
          <span>{exportError}</span>
          {previewBlobUrl && (
            <a
              href={previewBlobUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 bg-red-800 text-white px-3 py-1.5 rounded-md text-xs font-bold"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>ছবিটি নতুন ট্যাবে খুলুন (Tap to View & Save)</span>
            </a>
          )}
        </div>
      )}

      {/* Download Success Notice */}
      {downloadSuccess && (
        <div className="mb-4 p-3 bg-emerald-100 border border-emerald-300 rounded-lg text-emerald-900 text-xs sm:text-sm font-newspaper-serif text-center font-bold animate-fadeIn flex items-center justify-center gap-2">
          <Check className="w-4 h-4 text-emerald-700" />
          <span>আপনার Newspaper সফলভাবে ডাউনলোড হয়েছে!</span>
        </div>
      )}

      {/* Main Download Button & Share Button */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
        {/* Button 1: PNG Download */}
        <button
          onClick={handleDownloadPng}
          disabled={isExporting}
          className="flex items-center justify-center gap-2 bg-stone-950 hover:bg-stone-800 active:scale-[0.99] text-amber-50 px-5 py-3.5 rounded-xl text-base font-bold font-newspaper-serif transition-all shadow-md hover:shadow-lg disabled:opacity-60 cursor-pointer border border-stone-800"
        >
          <Download className={`w-5 h-5 text-amber-400 ${isExporting ? 'animate-bounce' : ''}`} />
          <span>{isExporting ? 'ছবি তৈরি হচ্ছে...' : '📥 PNG ডাউনলোড করুন'}</span>
        </button>

        {/* Button 2: Share / Copy */}
        <button
          onClick={handleShare}
          className="flex items-center justify-center gap-2 bg-amber-600 hover:bg-amber-700 active:scale-[0.99] text-white px-5 py-3.5 rounded-xl text-base font-bold font-newspaper-serif transition-all shadow-md hover:shadow-lg cursor-pointer"
        >
          {copiedLink ? (
            <>
              <Check className="w-5 h-5 text-emerald-200" />
              <span>লিংক কপি করা হয়েছে!</span>
            </>
          ) : (
            <>
              <Share2 className="w-5 h-5" />
              <span>সোশ্যাল মিডিয়ায় শেয়ার করুন</span>
            </>
          )}
        </button>
      </div>

      {/* Mobile-friendly Direct Image View button if blob is ready */}
      {previewBlobUrl && (
        <div className="mb-3 text-center">
          <a
            href={previewBlobUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-stone-700 bg-stone-200/90 hover:bg-stone-300 px-3 py-1.5 rounded-md font-newspaper-serif"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>মোবাইলে সরাসরি ছবি দেখতে ও সেভ করতে এখানে ক্লিক করুন</span>
          </a>
        </div>
      )}

      {/* Secondary Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {/* WhatsApp Direct */}
        <button
          onClick={handleWhatsAppShare}
          className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-3.5 py-2.5 rounded-lg text-sm font-newspaper-serif font-bold transition-colors shadow-xs cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp-এ পাঠান</span>
        </button>

        {/* Regenerate (Cycles through 5 different hilarious newspapers) */}
        <button
          onClick={onRegenerate}
          className="flex items-center justify-center gap-2 bg-[#fdfbf7] hover:bg-white text-stone-800 border-2 border-stone-400 hover:border-stone-700 px-3.5 py-2.5 rounded-lg text-sm font-newspaper-serif font-bold transition-colors shadow-xs cursor-pointer"
        >
          <RefreshCw className="w-4 h-4 text-amber-700" />
          <span>🎲 অন্য খবর ছাপুন</span>
        </button>

        {/* Make Friend's Newspaper */}
        <button
          onClick={onMakeNew}
          className="flex items-center justify-center gap-2 bg-stone-100 hover:bg-stone-200 text-stone-900 border border-stone-300 px-3.5 py-2.5 rounded-lg text-sm font-newspaper-serif font-bold transition-colors shadow-xs cursor-pointer"
        >
          <UserPlus className="w-4 h-4 text-stone-700" />
          <span>✏️ বন্ধুর Newspaper বানান</span>
        </button>
      </div>

      {/* Viral Loop Banner */}
      <div className="mt-6 p-4 bg-amber-50 border-2 border-amber-200 rounded-xl text-center font-newspaper-serif">
        <h4 className="text-base font-black text-amber-950 mb-1">
          🎉 এবার আপনার বন্ধুর নামে খবর বানান!
        </h4>
        <p className="text-xs sm:text-sm text-stone-700 mb-3">
          দেখুন সে ঘুমায় নাকি সব জায়গায় দেরি করে—আর বানিয়ে দিন তার নামেও চাঞ্চল্যকর পত্রিকা!
        </p>
        <button
          onClick={onMakeNew}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-amber-900 bg-amber-200/80 hover:bg-amber-300 px-4 py-2 rounded-lg transition-colors cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>নতুন বন্ধুর পত্রিকা শুরু করুন &rarr;</span>
        </button>
      </div>
    </div>
  );
};
